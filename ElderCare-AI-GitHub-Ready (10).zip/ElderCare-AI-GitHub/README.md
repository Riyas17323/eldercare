# ElderCare AI — prototype

A responsive React + TypeScript + Vite healthcare-family monitoring prototype inspired by the supplied dashboard screenshot. The visual theme uses a deep navy shell, white surfaces, cyan accents, readable typography and responsive navigation.

## Run locally
1. Install Node.js 20+.
2. `npm install`
3. `npm run dev`
4. Open the local URL printed by Vite.
5. `npm run build` to type-check and create a production build in `dist/`.

## Included modules
- Patient overview dashboard
- Medicine schedule with taken/unconfirmed toggles and escalation timeline
- Prescription upload UI and verification checklist
- Health monitor with clearly labelled sample data and Recharts
- Medical report manual entry and upload placeholder
- BMI calculator and water tracker
- Multilingual assistant UI (simulated safe responses; language preference selector)
- Medicine information demo catalogue
- Caregiver portal
- Emergency SOS preview (does not call or message)
- Analytics charts
- Patient profile and demo patient switch

## Prototype boundaries — important
This is a **front-end demo**, not a deployed or clinically validated service. Authentication is simulated. State is in browser memory and is not persisted to a database. Upload controls only demonstrate file selection; files are not uploaded or OCR-processed. AI responses are simulated; no Gemini request is made. Notifications are in-app UI feedback only. No SMS, voice calls, emergency calls, hospital messages, smartwatch connection or live device data are implemented. Demo readings and medicine rows are not medical instructions. Replace sample content with clinician-verified records before any real use.

## Suggested production integration
- Firebase Authentication: phone OTP with server-side rate limiting and abuse protection.
- Firestore: users, patient profiles, consent, caregiver relationships, medication schedules, dose events, readings, reports and audit records with strict security rules.
- Firebase Storage: private report and prescription objects, signed access, MIME validation and retention policy.
- Cloud Functions / trusted backend: reminder scheduling, 30-minute caregiver escalation, secondary escalation, audit logging and notification provider adapters.
- OCR: server-side extraction with confidence values; require human review and explicit verification before activating medication schedules.
- Gemini: call only from a trusted server endpoint; keep API keys in server environment variables; add safety policies, redaction, rate limits and clinical disclaimers.
- Notifications: FCM for push, and approved SMS/voice providers behind backend adapters. Do not imply delivery until provider receipts confirm it.
- Security: role-based authorization, least privilege, encryption, consent management, access logs, backup/retention policies and privacy/legal review for the deployment jurisdiction.

## Project structure
- `src/App.tsx` — application pages, demo state and navigation
- `src/styles.css` — responsive navy/white/cyan design system
- `src/main.tsx` — React entry point
